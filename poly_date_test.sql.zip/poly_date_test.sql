--
-- Database: `poly_date_test`
--
CREATE DATABASE IF NOT EXISTS `poly_date_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `poly_date_test`;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `identities`
--

CREATE TABLE `identities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `identities_users`
--

CREATE TABLE `identities_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `identity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `identities_users`
--

INSERT INTO `identities_users` (`id`, `user_id`, `identity_id`) VALUES
(1, 2103, 61),
(2, 2104, 62),
(3, 2104, 63),
(4, 2127, 67),
(5, 2128, 68),
(6, 2128, 69),
(7, 2151, 73),
(8, 2152, 74),
(9, 2152, 75),
(10, 2176, 81),
(11, 2177, 82),
(12, 2177, 83),
(13, 2202, 92),
(14, 2203, 93),
(15, 2203, 94),
(16, 2252, 103),
(17, 2253, 104),
(18, 2253, 105),
(19, 2275, 114),
(20, 2276, 115),
(21, 2276, 116),
(22, 2298, 125),
(23, 2299, 126),
(24, 2299, 127),
(25, 2321, 136),
(26, 2322, 137),
(27, 2322, 138),
(28, 2365, 155),
(29, 2366, 156),
(30, 2366, 157),
(31, 2412, 166),
(32, 2413, 167),
(33, 2413, 168),
(34, 2439, 177),
(35, 2440, 178),
(36, 2440, 179),
(37, 2466, 188),
(38, 2467, 189),
(39, 2467, 190),
(40, 2493, 199),
(41, 2494, 200),
(42, 2494, 201),
(43, 2520, 210),
(44, 2521, 211),
(45, 2521, 212),
(46, 2547, 221),
(47, 2548, 222),
(48, 2548, 223),
(49, 2574, 232),
(50, 2575, 233),
(51, 2575, 234),
(52, 2601, 243),
(53, 2602, 244),
(54, 2602, 245),
(55, 2627, 256),
(56, 2628, 257),
(57, 2628, 258),
(58, 2653, 269),
(59, 2654, 270),
(60, 2654, 271),
(61, 2679, 282),
(62, 2680, 283),
(63, 2680, 284),
(64, 2705, 295),
(65, 2706, 296),
(66, 2706, 297),
(67, 2729, 308),
(68, 2730, 309),
(69, 2730, 310),
(70, 2753, 322),
(71, 2754, 323),
(72, 2754, 324),
(73, 2783, 336),
(74, 2784, 337),
(75, 2784, 338);

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kinks`
--

CREATE TABLE `kinks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages_users`
--

CREATE TABLE `messages_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `message_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages_users`
--

INSERT INTO `messages_users` (`id`, `user_id`, `message_id`) VALUES
(1, 2105, 206),
(2, 2106, 206),
(3, 2107, 207),
(4, 2108, 207),
(5, 2129, 208),
(6, 2130, 208),
(7, 2131, 209),
(8, 2132, 209),
(9, 2153, 210),
(10, 2154, 210),
(11, 2155, 211),
(12, 2156, 211),
(13, 2178, 212),
(14, 2179, 212),
(15, 2180, 213),
(16, 2181, 213),
(17, 2204, 214),
(18, 2205, 214),
(19, 2206, 215),
(20, 2207, 215),
(21, 2254, 216),
(22, 2255, 216),
(23, 2256, 217),
(24, 2257, 217),
(25, 2277, 218),
(26, 2278, 218),
(27, 2279, 219),
(28, 2280, 219),
(29, 2300, 220),
(30, 2301, 220),
(31, 2302, 221),
(32, 2303, 221),
(33, 2323, 222),
(34, 2324, 222),
(35, 2325, 223),
(36, 2326, 223),
(37, 2367, 224),
(38, 2368, 224),
(39, 2369, 225),
(40, 2370, 225),
(41, 2414, 226),
(42, 2415, 226),
(43, 2416, 227),
(44, 2417, 227),
(45, 2441, 228),
(46, 2442, 228),
(47, 2443, 229),
(48, 2444, 229),
(49, 2468, 230),
(50, 2469, 230),
(51, 2470, 231),
(52, 2471, 231),
(53, 2495, 232),
(54, 2496, 232),
(55, 2497, 233),
(56, 2498, 233),
(57, 2522, 234),
(58, 2523, 234),
(59, 2524, 235),
(60, 2525, 235),
(61, 2549, 236),
(62, 2550, 236),
(63, 2551, 237),
(64, 2552, 237),
(65, 2576, 238),
(66, 2577, 238),
(67, 2578, 239),
(68, 2579, 239),
(69, 2603, 240),
(70, 2604, 240),
(71, 2605, 241),
(72, 2606, 241),
(73, 2629, 242),
(74, 2630, 242),
(75, 2631, 243),
(76, 2632, 243),
(77, 2655, 244),
(78, 2656, 244),
(79, 2657, 245),
(80, 2658, 245),
(81, 2681, 246),
(82, 2682, 246),
(83, 2683, 247),
(84, 2684, 247),
(85, 2707, 248),
(86, 2708, 248),
(87, 2709, 249),
(88, 2710, 249),
(89, 2731, 250),
(90, 2732, 250),
(91, 2733, 251),
(92, 2734, 251),
(93, 2755, 252),
(94, 2756, 252),
(95, 2757, 253),
(96, 2758, 253),
(97, 2785, 254),
(98, 2786, 254),
(99, 2787, 255),
(100, 2788, 255);

-- --------------------------------------------------------

--
-- Table structure for table `relationships`
--

CREATE TABLE `relationships` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id_one` int(11) DEFAULT NULL,
  `user_id_two` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `resource_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `seeking_genders`
--

CREATE TABLE `seeking_genders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `identity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seeking_genders`
--

INSERT INTO `seeking_genders` (`id`, `user_id`, `identity_id`) VALUES
(1, 2112, 64),
(2, 2113, 65),
(3, 2113, 66),
(4, 2136, 70),
(5, 2137, 71),
(6, 2137, 72),
(7, 2160, 76),
(8, 2161, 77),
(9, 2162, 79),
(10, 2162, 80),
(11, 2185, 84),
(12, 2186, 85),
(13, 2187, 87),
(14, 2188, 90),
(15, 2188, 91),
(16, 2211, 95),
(17, 2212, 96),
(18, 2213, 100),
(19, 2214, 101),
(20, 2214, 102),
(21, 2261, 106),
(22, 2262, 107),
(23, 2263, 111),
(24, 2264, 112),
(25, 2264, 113),
(26, 2284, 117),
(27, 2285, 118),
(28, 2286, 122),
(29, 2287, 123),
(30, 2287, 124),
(31, 2307, 128),
(32, 2308, 129),
(33, 2309, 133),
(34, 2310, 134),
(35, 2310, 135),
(36, 2330, 139),
(37, 2331, 140),
(38, 2332, 144),
(39, 2333, 145),
(40, 2333, 146),
(41, 2374, 158),
(42, 2375, 159),
(43, 2376, 163),
(44, 2377, 164),
(45, 2377, 165),
(46, 2421, 169),
(47, 2422, 170),
(48, 2423, 174),
(49, 2424, 175),
(50, 2424, 176),
(51, 2448, 180),
(52, 2449, 181),
(53, 2450, 185),
(54, 2451, 186),
(55, 2451, 187),
(56, 2475, 191),
(57, 2476, 192),
(58, 2477, 196),
(59, 2478, 197),
(60, 2478, 198),
(61, 2502, 202),
(62, 2503, 203),
(63, 2504, 207),
(64, 2505, 208),
(65, 2505, 209),
(66, 2529, 213),
(67, 2530, 214),
(68, 2531, 218),
(69, 2532, 219),
(70, 2532, 220),
(71, 2556, 224),
(72, 2557, 225),
(73, 2558, 229),
(74, 2559, 230),
(75, 2559, 231),
(76, 2583, 235),
(77, 2584, 236),
(78, 2585, 240),
(79, 2586, 241),
(80, 2586, 242),
(81, 2610, 246),
(82, 2611, 247),
(83, 2612, 251),
(84, 2613, 252),
(85, 2613, 253),
(86, 2620, 254),
(87, 2620, 255),
(88, 2622, 254),
(89, 2636, 259),
(90, 2637, 260),
(91, 2638, 264),
(92, 2639, 265),
(93, 2639, 266),
(94, 2646, 267),
(95, 2646, 268),
(96, 2648, 267),
(97, 2662, 272),
(98, 2663, 273),
(99, 2664, 277),
(100, 2665, 278),
(101, 2665, 279),
(102, 2672, 280),
(103, 2672, 281),
(104, 2674, 280),
(105, 2688, 285),
(106, 2689, 286),
(107, 2690, 290),
(108, 2691, 291),
(109, 2691, 292),
(110, 2698, 293),
(111, 2698, 294),
(112, 2700, 293),
(113, 2714, 298),
(114, 2715, 299),
(115, 2716, 303),
(116, 2717, 304),
(117, 2717, 305),
(118, 2738, 311),
(119, 2739, 312),
(120, 2740, 316),
(121, 2741, 317),
(122, 2741, 318),
(123, 2762, 325),
(124, 2763, 326),
(125, 2764, 330),
(126, 2765, 331),
(127, 2765, 332),
(128, 2772, 335),
(129, 2772, 334),
(130, 2774, 333),
(131, 2775, 333),
(132, 2776, 334),
(133, 2777, 335),
(134, 2778, 333),
(135, 2792, 339),
(136, 2793, 340),
(137, 2794, 344),
(138, 2795, 345),
(139, 2795, 346);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` text NOT NULL,
  `password` text NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `kink_friendly` tinyint(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `about_me` text,
  `interests` varchar(255) DEFAULT NULL,
  `seeking_relationship_type` varchar(255) DEFAULT NULL,
  `last_login` date DEFAULT NULL,
  `city_id` int(11) NOT NULL,
  `zip_code_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zip_codes`
--

CREATE TABLE `zip_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `zip_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `identities`
--
ALTER TABLE `identities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `identities_users`
--
ALTER TABLE `identities_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `kinks`
--
ALTER TABLE `kinks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `messages_users`
--
ALTER TABLE `messages_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `relationships`
--
ALTER TABLE `relationships`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `seeking_genders`
--
ALTER TABLE `seeking_genders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `zip_codes`
--
ALTER TABLE `zip_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=590;
--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `identities`
--
ALTER TABLE `identities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=347;
--
-- AUTO_INCREMENT for table `identities_users`
--
ALTER TABLE `identities_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kinks`
--
ALTER TABLE `kinks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=256;
--
-- AUTO_INCREMENT for table `messages_users`
--
ALTER TABLE `messages_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `relationships`
--
ALTER TABLE `relationships`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seeking_genders`
--
ALTER TABLE `seeking_genders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2796;
--
-- AUTO_INCREMENT for table `zip_codes`
--
ALTER TABLE `zip_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=444;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
